package org.yebigun.hrbank.domain.changelog.entity;

public enum ChangeType {
    CREATED,
    UPDATED,
    DELETED
}
