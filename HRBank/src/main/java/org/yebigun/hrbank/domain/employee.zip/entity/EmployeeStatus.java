package org.yebigun.hrbank.domain.employee.entity;

public enum EmployeeStatus {
    ACTIVE,
    ON_LEAVE,
    RESIGNED
}
