package org.yebigun.hrbank.domain.employee.exception;

import org.yebigun.hrbank.global.exception.UnsupportedException;

public class UnsupportedUnitException extends UnsupportedException {

    public UnsupportedUnitException(String message) {
        super(message);
    }
}
